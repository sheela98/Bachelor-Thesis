import pickle
import time
import sesum.sr as sr

with open('/Users/sheela_1/Documents/7_WS_23/Bachelorarbeit/einsum_problems/rand_supremacy2d-(7, 2, 2).pkl', 'rb') as file:
    format_string, l = pickle.load(file)

path, flops_log10, size_log2 = sr.compute_path(format_string, *l, seed=1, minimize='size', max_repeats=1024, max_time=10.0, progbar=True, is_outer_optimal=False, threshold_optimal=12)

tic = time.time()
result_sparse = sr.sesum(format_string, *l, path=path, backend="sparse", debug=True)
toc = time.time()
print("compute:", toc - tic, "s")
